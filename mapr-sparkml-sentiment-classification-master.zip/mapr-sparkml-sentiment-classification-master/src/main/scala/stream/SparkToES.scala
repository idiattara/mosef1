package stream
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.{OutputMode, Trigger}
import org.apache.spark.sql.types._

import java.util.concurrent.TimeUnit
object SparkToES{

  def main(args: Array[String]) {
    val modeldir="C:\\Users\\ibrah\\Downloads\\mapr-sparkml-sentiment-classification-master\\src\\modele\\MultilayerPerceptron"
    //val spark: SparkSession = SparkSession.builder().appName("flightdelay")
     // .master("local[*]").getOrCreate()

    val spark = SparkSession
      .builder
      // run app locally utilizing all cores
      .master("local[*]")
      .appName("toes")
      .config("es.nodes", "51.77.212.74")
      .config("es.port", "9200")
      .config("es.index.auto.create", "true") // this will ensure that index is also created on first POST
      .config("es.nodes.wan.only", "true") // needed to run against dockerized ES for local tests
      .config("es.net.http.auth.user", "admin")
      .config("es.net.http.auth.pass", "admin")
      .getOrCreate()

    spark.conf.set("spark.sql.session.timeZone", "UTC")
    //spark.conf.set("es.index.auto.create", "true")

    import spark.implicits._

    val schema = StructType(Array(
      StructField("thickness", DoubleType, true),
      StructField("size", DoubleType, true),
      StructField("shape", DoubleType, true),
      StructField("madh", DoubleType, true),
      StructField("epsize", DoubleType, true),
      StructField("bnuc", DoubleType, true),
      StructField("bchrom", DoubleType, true),
      StructField("nNuc", DoubleType, true),
      StructField("mit", DoubleType, true),
      StructField("user", StringType, true),
      StructField("nom_patient", StringType, true),
      StructField("prenom_patient", StringType, true),
      StructField("telephone_patient", StringType, true),
      StructField("lat", StringType, true),
      StructField("lon", StringType, true),
      StructField("ville", StringType, true),
      StructField("id", StringType, true)
    ))
    //{"medecin_user":"asarr050622","lat":14.7645042 ,"lon":-17.3660286,"nom_patient":"DIATTARA", "prenom_patient":"Ibrahima", "telephone_patient":"00221771445645", "ville":"dakar","thickness":5.0,"size":1.0,"shape":1.0,"madh":1.0,"epsize":2.0,"bnuc":3.0,"bchrom":1.0,"nNuc":1.0,"mit":2.0}
    val df = spark.createDataFrame(spark.sparkContext
      .emptyRDD[Row], schema)
    val assembler = new VectorAssembler().
      //setInputCols(df.drop("id","prenom","nom", "dateNaiss", "ville", "lon", "lat").columns)
      setInputCols(df.select("thickness", "size", "shape", "madh", "epsize", "bnuc", "bchrom", "nNuc", "mit").columns)
      .setOutputCol("features")
    //{"lat":14.7645042 ,"lon":-17.3660286,"nom":"DIATTARA", "prenom":"Ibrahima", "dateNaiss":"17-08-922", "ville":"dakar","thickness":5.0,"size":1.0,"shape":1.0,"madh":1.0,"epsize":2.0,"bnuc":3.0,"bchrom":1.0,"nNuc":1.0,"mit":2.0}
    val dfstreaming =spark.readStream.format("kafka")
      .option("kafka.bootstrap.servers", "51.77.212.74:9085")
      .option("subscribe", "Cancer_MultilayerPerceptron_Source")
      .option("group.id", "spark_Cancer_MultilayerPerceptron2")
      .option("startingOffsets", "latest")
      .load()
    val modelload=org.apache.spark.ml.classification.MultilayerPerceptronClassificationModel.load(modeldir)
    val df2s = dfstreaming.select($"value" cast "string" as "json").select(from_json($"json", schema) as "data").select("data.*")
    val df3s=modelload.transform(assembler.transform(df2s))
      //.withColumn("agent_timestamp", date_format(current_timestamp(),"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
     // .withColumn("location", concat($"lat", lit(','), $"lon"))
      .drop("features", "lon", "lat")
      .select(to_json(struct("*")).as("hit"))
      df3s.writeStream
      .outputMode(OutputMode.Append())
      .format("es")
      .option("checkpointLocation", "/tmp/checkpointLocationEs17")
        .option("es.mapping.id", "id")
        .option("es.resource", "yyyhjospital_index_for_all_cancer_multilayerperceptron/_doc")
        .start()
        .awaitTermination()
        //query.awaitTermination()
      //.option("es.mapping.id", "id")
        //.option("es.mapping.id", "id")
        // .option("es.resource", "log_hospital_index_for_all_cancer_multilayerperceptron/_doc")
      //.trigger(Trigger.ProcessingTime(5, TimeUnit.SECONDS))
      //.start("log_hospital_index_for_all_cancer_multilayerperceptron/_doc")
     // .awaitTermination()
/*
    df3s.writeStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "51.77.212.74:9085")
      .option("topic", "Cancer_MultilayerPerceptron_Result")
      .option("checkpointLocation", "/tata/Cancer_MultilayerPerceptron_Result2")
      .start()
    spark.streams.awaitAnyTermination()*/
  }
}
